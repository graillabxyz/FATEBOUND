import type { CardDef } from "../engine/types";
/** One global alpha set. No Legend ownership or source-pool classification. */
export const ALPHA_CARDS = [
  {
    "id": "crush",
    "name": "Crush",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 7
    },
    "text": "Deal 4 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 4
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 0,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "affinity": "might"
    },
    "set": "first-light",
    "collectorNumber": 1,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "root-ward",
    "name": "Root Ward",
    "category": "Ward",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 1,
      "max": 3
    },
    "text": "Gain 4 Ward.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 4
      }
    ],
    "priority": 20,
    "archetype": "Ward",
    "artIndex": 0,
    "tags": [
      "ward",
      "reaction",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "spirit"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 2,
    "balanceMetadata": {
      "intent": "Ward option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "barkskin",
    "name": "Barkskin",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 4,
      "max": 6
    },
    "text": "Gain 2 Ward. If the enemy attacks, deal 2 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "COUNTERSTRIKE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 0,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 3,
    "balanceMetadata": {
      "intent": "Counter option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "herensuge",
    "name": "Herensuge",
    "category": "Finisher",
    "timing": "ACTION",
    "requirement": {
      "count": 2,
      "min": 12
    },
    "text": "Deal 7 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 7
      }
    ],
    "priority": 40,
    "archetype": "Finisher",
    "artIndex": 0,
    "tags": [
      "finisher",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "allOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "wild"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 4,
    "balanceMetadata": {
      "intent": "Finisher option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "deep-roots",
    "name": "Deep Roots",
    "category": "Recovery",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 4
    },
    "text": "Heal 3 Life.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 3
      }
    ],
    "priority": 40,
    "archetype": "Recovery",
    "artIndex": 0,
    "tags": [
      "recovery",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "spirit"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 5,
    "balanceMetadata": {
      "intent": "Recovery option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "oakheart",
    "name": "Oakheart",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 4
    },
    "text": "Gain 2 Ward. Store +2 damage for next round.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 2
      },
      {
        "type": "STATUS",
        "status": "power",
        "amount": 2,
        "duration": 1
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 0,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "allOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "might"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 6,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "thorn-return",
    "name": "Thorn Return",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 3,
      "max": 5
    },
    "text": "If the enemy attacks, gain 2 Ward and deal 3 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "GUARD",
            "amount": 2
          },
          {
            "type": "COUNTERSTRIKE",
            "amount": 3
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 0,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "shadow"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 7,
    "balanceMetadata": {
      "intent": "Counter option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "fell-the-axe",
    "name": "Fell the Axe",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5
    },
    "text": "Deal 3 damage. If guarding, deal 1 more.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3
      },
      {
        "type": "CONDITIONAL",
        "condition": "guarding",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 1
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 0,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 8,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "sanctuary",
    "name": "Sanctuary",
    "category": "Ward",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "symbol": "guard"
    },
    "text": "Gain 6 Ward and cleanse all negative statuses.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 6
      },
      {
        "type": "CLEANSE"
      }
    ],
    "priority": 20,
    "archetype": "Ward",
    "artIndex": 0,
    "tags": [
      "ward",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "affinity": "spirit"
    },
    "set": "first-light",
    "collectorNumber": 9,
    "balanceMetadata": {
      "intent": "Ward option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "silken-cut",
    "name": "Silken Cut",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5
    },
    "text": "Deal 3 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 1,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": null,
    "set": "first-light",
    "collectorNumber": 10,
    "balanceMetadata": {
      "intent": "Attack option; universal access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "read-the-thread",
    "name": "Read the Thread",
    "category": "Prediction",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 4
    },
    "text": "Deal 2 damage. If the enemy attacks, deal 2 more.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Prediction",
    "artIndex": 1,
    "tags": [
      "prediction",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 11,
    "balanceMetadata": {
      "intent": "Prediction option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "web-shift",
    "name": "Web Shift",
    "category": "Manipulation",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "symbol": "swap"
    },
    "text": "Redirect the declared enemy action back to its user.",
    "effects": [
      {
        "type": "REDIRECT"
      }
    ],
    "priority": 20,
    "archetype": "Manipulation",
    "artIndex": 1,
    "tags": [
      "manipulation",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "chaos"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 12,
    "balanceMetadata": {
      "intent": "Manipulation option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "false-promise",
    "name": "False Promise",
    "category": "Prediction",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 3,
      "max": 5
    },
    "text": "If the enemy guards, deal 5 damage; otherwise deal 1.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 1
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyGuarding",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 4
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Prediction",
    "artIndex": 1,
    "tags": [
      "prediction",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "affinity": "guile"
    },
    "set": "first-light",
    "collectorNumber": 13,
    "balanceMetadata": {
      "intent": "Prediction option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "unravel",
    "name": "Unravel",
    "category": "Manipulation",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 3
    },
    "text": "Cancel the declared enemy action, including healing.",
    "effects": [
      {
        "type": "CANCEL"
      }
    ],
    "priority": 20,
    "archetype": "Manipulation",
    "artIndex": 1,
    "tags": [
      "manipulation",
      "reaction",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "allOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 14,
    "balanceMetadata": {
      "intent": "Manipulation option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "borrowed-time",
    "name": "Borrowed Time",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 4
    },
    "text": "Gain 2 Ward. Store +1 damage for next round.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 2
      },
      {
        "type": "STATUS",
        "status": "power",
        "amount": 1,
        "duration": 1
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 1,
    "tags": [
      "setup",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 15,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "spider-s-patience",
    "name": "Spider’s Patience",
    "category": "Recovery",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 1,
      "max": 2
    },
    "text": "Heal 3 Life.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 3
      }
    ],
    "priority": 40,
    "archetype": "Recovery",
    "artIndex": 1,
    "tags": [
      "recovery",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "shadow"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 16,
    "balanceMetadata": {
      "intent": "Recovery option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "story-s-end",
    "name": "Story’s End",
    "category": "Finisher",
    "timing": "ACTION",
    "requirement": {
      "count": 2,
      "min": 11
    },
    "text": "Deal 6 damage. Deal 1 more if an enemy card is known.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 6
      },
      {
        "type": "CONDITIONAL",
        "condition": "knownEnemy",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 1
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Finisher",
    "artIndex": 1,
    "tags": [
      "finisher",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "allOf": [
            {
              "affinity": "guile"
            },
            {
              "affinity": "might"
            }
          ]
        },
        {
          "allOf": [
            {
              "affinity": "guile"
            },
            {
              "affinity": "wisdom"
            }
          ]
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 17,
    "balanceMetadata": {
      "intent": "Finisher option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "hidden-meaning",
    "name": "Hidden Meaning",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "any": true
    },
    "text": "Gain 1 Ward. If the enemy attacks, deal 1 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 1
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "COUNTERSTRIKE",
            "amount": 1
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 1,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": null,
    "set": "first-light",
    "collectorNumber": 18,
    "balanceMetadata": {
      "intent": "Counter option; universal access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "gale-cut",
    "name": "Gale Cut",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5
    },
    "text": "Deal 3 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3
      }
    ],
    "priority": 40,
    "preferred": 5,
    "archetype": "Attack",
    "artIndex": 2,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 19,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "perfect-riposte",
    "name": "Perfect Riposte",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 4,
      "max": 6
    },
    "text": "Gain 2 Ward. If attacked, deal 2 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "COUNTERSTRIKE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 20,
    "preferred": 5,
    "archetype": "Counter",
    "artIndex": 2,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wisdom"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 20,
    "balanceMetadata": {
      "intent": "Counter option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "sky-sever",
    "name": "Sky Sever",
    "category": "Finisher",
    "timing": "ACTION",
    "requirement": {
      "count": 2,
      "min": 11
    },
    "text": "Deal 6 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 6
      }
    ],
    "priority": 40,
    "preferred": 12,
    "archetype": "Finisher",
    "artIndex": 2,
    "tags": [
      "finisher",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "mythic",
    "affinityRequirements": {
      "allOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 21,
    "balanceMetadata": {
      "intent": "Finisher option; overlapping Affinity access",
      "complexity": 4,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "first-wind",
    "name": "First Wind",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 4
    },
    "text": "Deal 2 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 2
      }
    ],
    "priority": 40,
    "preferred": 3,
    "archetype": "Attack",
    "artIndex": 2,
    "tags": [
      "attack",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": null,
    "set": "first-light",
    "collectorNumber": 22,
    "balanceMetadata": {
      "intent": "Attack option; universal access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "still-mind",
    "name": "Still Mind",
    "category": "Recovery",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 3
    },
    "text": "Heal 2 Life and cleanse negative statuses.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 2
      },
      {
        "type": "CLEANSE"
      }
    ],
    "priority": 40,
    "archetype": "Recovery",
    "artIndex": 2,
    "tags": [
      "recovery",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wisdom"
        },
        {
          "affinity": "spirit"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 23,
    "balanceMetadata": {
      "intent": "Recovery option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "raven-wing",
    "name": "Raven Wing",
    "category": "Manipulation",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "symbol": "redirect"
    },
    "text": "Reduce the first enemy damage effect by 4.",
    "effects": [
      {
        "type": "BLOCK_EFFECT",
        "amount": 4
      }
    ],
    "priority": 20,
    "archetype": "Manipulation",
    "artIndex": 2,
    "tags": [
      "manipulation",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 24,
    "balanceMetadata": {
      "intent": "Manipulation option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "peak-strike",
    "name": "Peak Strike",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 7
    },
    "text": "Deal 4 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 4
      }
    ],
    "priority": 40,
    "preferred": 7,
    "archetype": "Attack",
    "artIndex": 2,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "allOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 25,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "windstep",
    "name": "Windstep",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "any": true
    },
    "text": "Gain 1 Ward. Store +1 damage for next round.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 1
      },
      {
        "type": "STATUS",
        "status": "power",
        "amount": 1,
        "duration": 1
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 2,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": null,
    "set": "first-light",
    "collectorNumber": 26,
    "balanceMetadata": {
      "intent": "Setup option; universal access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "watchful-blade",
    "name": "Watchful Blade",
    "category": "Prediction",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 5,
      "max": 7
    },
    "text": "If the enemy attacks, deal 5 damage.",
    "effects": [
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 5
          }
        ]
      }
    ],
    "priority": 20,
    "preferred": 6,
    "archetype": "Prediction",
    "artIndex": 2,
    "tags": [
      "prediction",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wisdom"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 27,
    "balanceMetadata": {
      "intent": "Prediction option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "mountain-silence",
    "name": "Mountain Silence",
    "category": "Ward",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 8
    },
    "text": "Gain 5 Ward.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 5
      }
    ],
    "priority": 20,
    "archetype": "Ward",
    "artIndex": 2,
    "tags": [
      "ward",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "spirit"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 28,
    "balanceMetadata": {
      "intent": "Ward option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "falling-leaf",
    "name": "Falling Leaf",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 1,
      "max": 2
    },
    "text": "Deal 2 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 2
      }
    ],
    "priority": 40,
    "preferred": 1,
    "archetype": "Attack",
    "artIndex": 2,
    "tags": [
      "attack",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 29,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "branch-lash",
    "name": "Branch Lash",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5,
      "max": 8
    },
    "text": "Deal 4 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 4
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 3,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "affinity": "wild"
    },
    "set": "first-light",
    "collectorNumber": 30,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "moss-mantle",
    "name": "Moss Mantle",
    "category": "Ward",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 1,
      "max": 3
    },
    "text": "Gain 3 Ward and heal 1 Life.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 3
      },
      {
        "type": "HEAL",
        "amount": 1
      }
    ],
    "priority": 20,
    "archetype": "Ward",
    "artIndex": 3,
    "tags": [
      "ward",
      "reaction",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "allOf": [
            {
              "affinity": "wild"
            },
            {
              "affinity": "spirit"
            }
          ]
        },
        {
          "affinity": "shadow"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 31,
    "balanceMetadata": {
      "intent": "Ward option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "wolf-shape",
    "name": "Wolf Shape",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 7
    },
    "text": "Deal 3 damage. If behind in Life, deal 2 more.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3
      },
      {
        "type": "CONDITIONAL",
        "condition": "behind",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 3,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "shadow"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 32,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "lost-path",
    "name": "Lost Path",
    "category": "Manipulation",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 4,
      "max": 6
    },
    "text": "Reduce the first enemy damage effect by 3.",
    "effects": [
      {
        "type": "BLOCK_EFFECT",
        "amount": 3
      }
    ],
    "priority": 20,
    "archetype": "Manipulation",
    "artIndex": 3,
    "tags": [
      "manipulation",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "chaos"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 33,
    "balanceMetadata": {
      "intent": "Manipulation option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "new-skin",
    "name": "New Skin",
    "category": "Recovery",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 3,
      "max": 5
    },
    "text": "Heal 3 Life and cleanse negative statuses.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 3
      },
      {
        "type": "CLEANSE"
      }
    ],
    "priority": 40,
    "archetype": "Recovery",
    "artIndex": 3,
    "tags": [
      "recovery",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "chaos"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 34,
    "balanceMetadata": {
      "intent": "Recovery option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "bramble-trap",
    "name": "Bramble Trap",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 4
    },
    "text": "If the enemy attacks, gain 2 Ward and deal 2 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "GUARD",
            "amount": 2
          },
          {
            "type": "COUNTERSTRIKE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 3,
    "tags": [
      "counter",
      "reaction",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "guile"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 35,
    "balanceMetadata": {
      "intent": "Counter option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "wild-bloom",
    "name": "Wild Bloom",
    "category": "Recovery",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "symbol": "guard"
    },
    "text": "Heal 4 Life and gain 2 Ward.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 4
      },
      {
        "type": "GUARD",
        "amount": 2
      }
    ],
    "priority": 40,
    "archetype": "Recovery",
    "artIndex": 3,
    "tags": [
      "recovery",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "spirit"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 36,
    "balanceMetadata": {
      "intent": "Recovery option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "crooked-bough",
    "name": "Crooked Bough",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 3,
      "max": 4
    },
    "text": "Deal 3 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 3,
    "tags": [
      "attack",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wild"
        },
        {
          "affinity": "chaos"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 37,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "night-spores",
    "name": "Night Spores",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 6
    },
    "text": "Enemy takes 2 damage next round. Gain 1 Ward.",
    "effects": [
      {
        "type": "STATUS",
        "status": "poison",
        "target": "enemy",
        "amount": 2,
        "duration": 1
      },
      {
        "type": "GUARD",
        "amount": 1
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 3,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "shadow"
        },
        {
          "affinity": "chaos"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 38,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "sun-lance",
    "name": "Sun Lance",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 6
    },
    "text": "Deal 4 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 4
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 4,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "spirit"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 39,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "first-light",
    "name": "First Light",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 5
    },
    "text": "Heal 1 Life. Store +1 damage for next round.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 1
      },
      {
        "type": "STATUS",
        "status": "power",
        "amount": 1,
        "duration": 1
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 4,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "spirit"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 40,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "offering",
    "name": "Offering",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "any": true
    },
    "text": "Spend 2 Life. Store +3 damage for next round.",
    "effects": [
      {
        "type": "CONVERT",
        "from": "hp",
        "amount": 2,
        "effects": [
          {
            "type": "STATUS",
            "status": "power",
            "amount": 3,
            "duration": 1
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 4,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "mythic",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "shadow"
        },
        {
          "affinity": "spirit"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 41,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 4,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "dawn-shield",
    "name": "Dawn Shield",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 4
    },
    "text": "Gain 2 Ward. If the enemy attacks, deal 1 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyAttacking",
        "effects": [
          {
            "type": "COUNTERSTRIKE",
            "amount": 1
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 4,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "spirit"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 42,
    "balanceMetadata": {
      "intent": "Counter option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "open-sky",
    "name": "Open Sky",
    "category": "Manipulation",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 5,
      "max": 7
    },
    "text": "Reduce the first enemy damage effect by 2. Gain 1 Ward.",
    "effects": [
      {
        "type": "BLOCK_EFFECT",
        "amount": 2
      },
      {
        "type": "GUARD",
        "amount": 1
      }
    ],
    "priority": 20,
    "archetype": "Manipulation",
    "artIndex": 4,
    "tags": [
      "manipulation",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "wisdom"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 43,
    "balanceMetadata": {
      "intent": "Manipulation option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "burning-crown",
    "name": "Burning Crown",
    "category": "Finisher",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 10
    },
    "text": "Spend 2 Life to deal 7 damage.",
    "effects": [
      {
        "type": "CONVERT",
        "from": "hp",
        "amount": 2,
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 7
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Finisher",
    "artIndex": 4,
    "tags": [
      "finisher",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "mythic",
    "affinityRequirements": {
      "anyOf": [
        {
          "allOf": [
            {
              "affinity": "might"
            },
            {
              "affinity": "spirit"
            }
          ]
        },
        {
          "allOf": [
            {
              "affinity": "might"
            },
            {
              "affinity": "chaos"
            }
          ]
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 44,
    "balanceMetadata": {
      "intent": "Finisher option; overlapping Affinity access",
      "complexity": 4,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "horizon",
    "name": "Horizon",
    "category": "Prediction",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5
    },
    "text": "Deal 2 damage. With three actions, deal 2 more.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "threeActions",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Prediction",
    "artIndex": 4,
    "tags": [
      "prediction",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "allOf": [
            {
              "affinity": "might"
            },
            {
              "affinity": "wisdom"
            }
          ]
        },
        {
          "affinity": "guile"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 45,
    "balanceMetadata": {
      "intent": "Prediction option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "daring-feint",
    "name": "Daring Feint",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 4,
      "max": 7
    },
    "text": "Deal 3 damage. With an unused Omen, deal 2 more.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3
      },
      {
        "type": "CONDITIONAL",
        "condition": "unusedDie",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 5,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "might"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 46,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "turnabout",
    "name": "Turnabout",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 3,
      "max": 5
    },
    "text": "Gain 2 Ward. If behind in Life, deal 3 damage. Counter damage occurs after you receive attack damage.",
    "effects": [
      {
        "type": "GUARD",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "behind",
        "effects": [
          {
            "type": "COUNTERSTRIKE",
            "amount": 3
          }
        ]
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 5,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "shadow"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 47,
    "balanceMetadata": {
      "intent": "Counter option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "rising-tide",
    "name": "Rising Tide",
    "category": "Recovery",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 4
    },
    "text": "Heal 2 Life. If behind in Life, heal 1 more.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "behind",
        "effects": [
          {
            "type": "HEAL",
            "amount": 1
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Recovery",
    "artIndex": 5,
    "tags": [
      "recovery",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "spirit"
        },
        {
          "affinity": "wild"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 48,
    "balanceMetadata": {
      "intent": "Recovery option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "island-pull",
    "name": "Island Pull",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 8
    },
    "text": "Deal 5 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 5
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 5,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "affinity": "might"
    },
    "set": "first-light",
    "collectorNumber": 49,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "bold-wager",
    "name": "Bold Wager",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "any": true
    },
    "text": "Spend 1 Life. Store +2 damage for next round.",
    "effects": [
      {
        "type": "CONVERT",
        "from": "hp",
        "amount": 1,
        "effects": [
          {
            "type": "STATUS",
            "status": "power",
            "amount": 2,
            "duration": 1
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 5,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "uncommon",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "shadow"
        },
        {
          "affinity": "chaos"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 50,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 2,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "wavebreaker",
    "name": "Wavebreaker",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5,
      "max": 6
    },
    "text": "Convert up to 3 Ward into damage, then deal 2 damage.",
    "effects": [
      {
        "type": "CONVERT",
        "from": "guard",
        "amount": 3,
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 1
          }
        ]
      },
      {
        "type": "DAMAGE",
        "amount": 2
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 5,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "rare",
    "affinityRequirements": {
      "anyOf": [
        {
          "allOf": [
            {
              "affinity": "might"
            },
            {
              "affinity": "spirit"
            }
          ]
        },
        {
          "allOf": [
            {
              "affinity": "might"
            },
            {
              "affinity": "guile"
            }
          ]
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 51,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "against-the-current",
    "name": "Against the Current",
    "category": "Prediction",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 4
    },
    "text": "Deal 2 damage. If the enemy guards, deal 2 more.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 2
      },
      {
        "type": "CONDITIONAL",
        "condition": "enemyGuarding",
        "effects": [
          {
            "type": "DAMAGE",
            "amount": 2
          }
        ]
      }
    ],
    "priority": 40,
    "archetype": "Prediction",
    "artIndex": 5,
    "tags": [
      "prediction",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "order"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 52,
    "balanceMetadata": {
      "intent": "Prediction option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "quick-strike",
    "name": "Quick Strike",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 1,
      "max": 3
    },
    "text": "Deal 2 damage.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 2
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 0,
    "tags": [
      "attack",
      "action",
      "low-value"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": null,
    "set": "first-light",
    "collectorNumber": 53,
    "balanceMetadata": {
      "intent": "Attack option; universal access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "web-turn",
    "name": "Web Turn",
    "category": "Manipulation",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 6,
      "max": 6
    },
    "text": "Redirect the declared enemy action back to its user.",
    "effects": [
      {
        "type": "REDIRECT"
      }
    ],
    "priority": 20,
    "archetype": "Manipulation",
    "artIndex": 1,
    "tags": [
      "manipulation",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "guile"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 54,
    "balanceMetadata": {
      "intent": "Manipulation option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "precision-cut",
    "name": "Precision Cut",
    "category": "Attack",
    "timing": "ACTION",
    "requirement": {
      "count": 1,
      "min": 5,
      "max": 5
    },
    "text": "Deal 3 damage; ignore 1 Ward.",
    "effects": [
      {
        "type": "DAMAGE",
        "amount": 3,
        "guardPierce": 1
      }
    ],
    "priority": 40,
    "archetype": "Attack",
    "artIndex": 2,
    "tags": [
      "attack",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": {
      "allOf": [
        {
          "affinity": "might"
        },
        {
          "affinity": "wisdom"
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 55,
    "balanceMetadata": {
      "intent": "Attack option; overlapping Affinity access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "counterstrike",
    "name": "Counterstrike",
    "category": "Counter",
    "timing": "REACTION",
    "requirement": {
      "count": 1,
      "min": 8
    },
    "text": "After receiving attack damage, deal 2 damage back.",
    "effects": [
      {
        "type": "COUNTERSTRIKE",
        "amount": 2
      }
    ],
    "priority": 20,
    "archetype": "Counter",
    "artIndex": 0,
    "tags": [
      "counter",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "rarity": "common",
    "affinityRequirements": null,
    "set": "first-light",
    "collectorNumber": 56,
    "balanceMetadata": {
      "intent": "Counter option; universal access",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "ritual",
    "name": "Ritual",
    "category": "Setup",
    "timing": "ACTION",
    "requirement": {
      "count": 2,
      "exact": 10,
      "min": 10,
      "max": 10
    },
    "text": "Two Omens totaling exactly 10: heal 4 and gain 2 Ward.",
    "effects": [
      {
        "type": "HEAL",
        "amount": 4
      },
      {
        "type": "GUARD",
        "amount": 2
      }
    ],
    "priority": 40,
    "archetype": "Setup",
    "artIndex": 4,
    "tags": [
      "setup",
      "action"
    ],
    "mechanicalVersion": 5,
    "rarity": "mythic",
    "affinityRequirements": {
      "anyOf": [
        {
          "allOf": [
            {
              "affinity": "spirit"
            },
            {
              "affinity": "wisdom"
            }
          ]
        },
        {
          "allOf": [
            {
              "affinity": "wild"
            },
            {
              "affinity": "chaos"
            }
          ]
        }
      ]
    },
    "set": "first-light",
    "collectorNumber": 57,
    "balanceMetadata": {
      "intent": "Setup option; overlapping Affinity access",
      "complexity": 4,
      "repeatability": "resource-limited",
      "reviewNotes": "Prototype; measured per legal Legend and Omen profile, not rarity-scaled."
    }
  },
  {
    "id": "meditate",
    "name": "Meditate",
    "affinityRequirements": null,
    "requirement": {
      "count": 1,
      "min": 2,
      "max": 5
    },
    "text": "Gain 1 Focus.",
    "effects": [
      {
        "type": "GAIN_CONTROL",
        "amount": 1
      }
    ],
    "timing": "ACTION",
    "rarity": "common",
    "set": "first-light",
    "collectorNumber": 58,
    "category": "Setup",
    "archetype": "Omen utility",
    "priority": 40,
    "artIndex": 1,
    "tags": [
      "omen",
      "utility",
      "action"
    ],
    "mechanicalVersion": 5,
    "balanceMetadata": {
      "intent": "Gain 1 Focus.",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Consumes an Omen; no free reusable activation."
    }
  },
  {
    "id": "hollow-sign",
    "name": "Hollow Sign",
    "affinityRequirements": {
      "anyOf": [
        {
          "affinity": "chaos"
        },
        {
          "affinity": "shadow"
        }
      ]
    },
    "requirement": {
      "count": 1,
      "void": true,
      "unused": 1
    },
    "text": "Flip your first other available or Held Omen.",
    "effects": [
      {
        "type": "FLIP_DIE",
        "target": "self",
        "omenTarget": "unspent"
      }
    ],
    "timing": "ACTION",
    "rarity": "rare",
    "set": "first-light",
    "collectorNumber": 59,
    "category": "Manipulation",
    "archetype": "Omen utility",
    "priority": 40,
    "artIndex": 1,
    "tags": [
      "omen",
      "utility",
      "action"
    ],
    "mechanicalVersion": 5,
    "balanceMetadata": {
      "intent": "Flip your first other available or Held Omen.",
      "complexity": 3,
      "repeatability": "resource-limited",
      "reviewNotes": "Consumes an Omen; no free reusable activation."
    }
  },
  {
    "id": "thread-the-path",
    "name": "Thread the Path",
    "affinityRequirements": {
      "affinity": "wisdom"
    },
    "requirement": {
      "count": 1,
      "exact": 5,
      "min": 5,
      "max": 5
    },
    "text": "Shift the first Omen paying for the enemy Action down by 1. Recheck its requirement.",
    "effects": [
      {
        "type": "SHIFT_DIE",
        "target": "enemy",
        "direction": -1
      }
    ],
    "timing": "REACTION",
    "rarity": "uncommon",
    "set": "first-light",
    "collectorNumber": 60,
    "category": "Manipulation",
    "archetype": "Omen utility",
    "priority": 20,
    "artIndex": 1,
    "tags": [
      "omen",
      "utility",
      "reaction"
    ],
    "mechanicalVersion": 5,
    "balanceMetadata": {
      "intent": "Shift the first Omen paying for the enemy Action down by 1. Recheck its requirement.",
      "complexity": 1,
      "repeatability": "resource-limited",
      "reviewNotes": "Consumes an Omen; no free reusable activation."
    }
  }
] satisfies Omit<CardDef,"requirementLabel">[];
