import { useState } from "react";
import { GLOSSARY } from "../content/terminology";
import { Omen } from "./components";
import { omenById } from "../content/omens";
import { FaceExplanation } from "./OmenFaces";
export const TUTORIAL_STEPS = [
  ["Legend", "This is your Legend. Reduce the enemy Legend to 0 Life to win."],
  [
    "Hand",
    "Choose four Cards from one shared pool. Your Legend’s Affinities determine compatibility. They stay reusable all Match.",
  ],
  [
    "Omens",
    "Choose three collectible Omens before battle. Their faces are fixed.",
  ],
  [
    "Faces",
    "Omens can have Values, Sigils, or Voids. Tap a face below to inspect it.",
  ],
  [
    "Roll",
    "Roll your Omens. The opening player chooses 1, the second chooses 2. All 3 from your second Turn. Initiative winner always goes first.",
  ],
  [
    "Act",
    "A requirement of two Values totaling 11+ spends BOTH Omens. They cannot be used again before your next roll. The Card stays reusable in your Hand.",
  ],
  [
    "Focus",
    "Use Focus to Shift by 1 or Flip to the opposite face. Shift costs 1; Flip costs 2.",
  ],
  [
    "Hold",
    "You don’t have to spend every Omen on your Turn. End your Turn to Hold unused Omens.",
  ],
  [
    "React",
    "Held Omens can activate Reactions during your opponent’s Turn. React or Pass within 5 seconds.",
  ],
  [
    "Ward",
    "5 Ward blocks 5 damage, then is gone. An 8-damage attack removes 5 Ward and 3 Life. Leftover Ward expires at your next turn start.",
  ],
] as const;
export function TutorialSteps() {
  const [step, setStep] = useState(0),
    [face, setFace] = useState(0);
  const omen = omenById["guardian-d6"];
  return (
    <div className="tutorial-steps">
      <small>
        {step + 1} / {TUTORIAL_STEPS.length}
      </small>
      <h3>{TUTORIAL_STEPS[step][0]}</h3>
      <p>{TUTORIAL_STEPS[step][1]}</p>
      {step === 3 && (
        <>
          <div className="tutorial-face-demo">
            {[1, 5, 0].map((i) => (
              <Omen
                key={i}
                definition={omen}
                face={omen.faces[i]}
                selected={face === i}
                onClick={() => setFace(i)}
              />
            ))}
          </div>
          <FaceExplanation face={omen.faces[face]} />
        </>
      )}
      <div className="tutorial-step-buttons">
        <button disabled={step === 0} onClick={() => setStep(step - 1)}>
          Back
        </button>
        <button disabled={step === TUTORIAL_STEPS.length-1} onClick={() => setStep(step + 1)}>
          Next
        </button>
      </div>
    </div>
  );
}
export function Glossary() {
  return (
    <div className="mechanical-glossary">
      <h3>OMNIPATH glossary</h3>
      {GLOSSARY.map(([term, definition]) => (
        <details key={term}>
          <summary>{term}</summary>
          <p>{definition}</p>
        </details>
      ))}
    </div>
  );
}
